package com.company;

public enum ActivityStatus {JOINED("Joined"), AVAILABLE("Available to join");
    String activityStatus = null;

    ActivityStatus(String friendStatus){
        this.activityStatus = activityStatus;
    }
}
