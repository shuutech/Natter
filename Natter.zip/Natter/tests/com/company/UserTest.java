//package com.company;
//
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//class UserTest {
//
//    @Test
//    void setUserId() {
//    }
//
//    @Test
//    void setUserName(){
//
//        //must not contain spaces or special characters
//        // Username must be unique
////        Assertions.assertThrows(Exception.class, () -> {
////            User user= new User();
////            user.setUserName("abc");
////
////            User user1= new User();
////            user1.setUserName(user.getUserName());
////            System.out.println(user1.getUserName());
////        });
//
//    }
//
//    @Test
//    void setFirstName() {
//    }
//
//    @Test
//    void setLastName() {
//    }
//
//    @Test
//    void setEmail() {
//    }
//
//    @Test
//    void setPhoneNumber() {
//    }
//
//    @Test
//    void setUserLocation() {
//    }
//
//
//
//
//}